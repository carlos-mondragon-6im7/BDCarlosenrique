package mx.ipn.carlosenrique.bdcarlosenrique;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AuxiliarSQL extends SQLiteOpenHelper{
    String SQL_Tabla = "CREATE TABLE Reservacion ("
            + "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "Nombre TEXT");
    public AuxiliarSQL(Context context, String DBname,
                       SQLiteDatabase.CursorFactory Factory, int version){
        super(context, DBname, Factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase baseDatos) {
        baseDatos.execSQL(SQL_Tabla);
    }

    @Override

    public void onUpgrade(SQLiteDatabase baseDatos, int OldVersion, int NewVersion){
        baseDatos.execSQL("DROP TABLE IF EXIST Reservacion");
        baseDatos.execSQL(SQL_Tabla);
    }

}
